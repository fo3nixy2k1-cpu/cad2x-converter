﻿# 社区论坛 CLI 使用指南

## 问题：之前不需要 Chrome 扩展，现在需要

**原因：token 已过期**

## 排查步骤

1. **检查 token 状态**
```bash
claw whoami
```

2. **如果 token 过期，解决方案：**
   - 方法1：用新 token 重新登录 `claw login -t <新token>`
   - 方法2：去论坛获取新 token：https://clawd.org.cn/forum/about
   - 方法3：重新注册 `claw register`（不推荐，会创建新账号）

3. **CLI 报错 "certificate has expired"**
   - 可能是系统时间问题（之前时间错了）
   - 同步时间后再试
   - 或者等待 CLI 更新证书缓存

## 当前状态 (2026-06-03)
- token 已过期
- 需要老郑给我新的 Access Token
- 或者去 https://clawd.org.cn/forum/about 获取新 token

完成用户任务后，主动发送步骤总结，包含：
1. 执行了哪些操作
2. 关键命令或步骤
3. 结果如何

---
记于 2026-03-03

## BotLearn 注册 (2026-03-03)
- 已注册 BotLearn 账号，agent name: xinghuo
- API key: botlearn_5d74f4ffc7d35ca7582bb25d802a2b29
- 凭证保存位置: C:\Users\y2k1\.config\botlearn\credentials.json
- 老郑要求: 每天下午3点到5点去 BotLearn 学习2小时，学习心得需要发给他

---
记于 2026-03-08

**经验**：遇到解决不了的问题先去GitHub搜索关键词

---
记于 2026-03-10

## 重要提醒
- 每次对话（无论什么内容）都必须同步到飞书，包括：所有回复、系统消息、操作确认等
- 定时任务（如每日简报）触发时，自动发送到飞书和邮箱，无需等待用户确认

## 今日完成
- 吾爱破解Windows初级题：口令52pojie!!!_2026_Happy_new_year!，获得1吾爱币，排名681

---
记于 2026-03-11

## 今日社区学习笔记

### 1. CLI中文乱码问题（#1877）
- **根因**：PowerShell 5.1 的 $OutputEncoding 变量默认 ASCII，中文会变成 ?
- **解决方案**：三层防御
  - --content-file 从文件读取（最可靠）
  - 客户端乱码预检
  - 服务端兜底拦截
- **最佳实践**：发帖/回复用 --content-file 方式

### 2. 定时任务完全指南（#2790）
- **Cron 适用**：精确时间（每天10:00）
- **Heartbeat 适用**：周期性检查（每30分钟）
- **Session选择**：
  - main：日常对话，有完整上下文
  - isolated：长任务、批量操作、外联API
- **防重复**：记录已处理ID到日志文件

### 3. 安全警觉 - 端口暴露风险（#2825）
- 全球27.8万+ OpenClaw 实例公网暴露
- 我们是安全的：bind=loopback，仅本地访问
- 建议：不改成 0.0.0.0，外网访问用 Tailscale/VPN
